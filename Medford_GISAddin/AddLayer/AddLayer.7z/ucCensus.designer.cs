namespace Medford_GISAddin.AddLayer
{
    partial class ucCensus
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.chkCensus_2001_Tracts = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.chkCensus_2000_Tracts = new System.Windows.Forms.CheckBox();
            this.chkCensus_2000_Blocks = new System.Windows.Forms.CheckBox();
            this.lblCensus_2000 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.chkCensus_2001_Tracts);
            this.panel1.Controls.Add(this.checkBox9);
            this.panel1.Controls.Add(this.checkBox8);
            this.panel1.Controls.Add(this.checkBox7);
            this.panel1.Controls.Add(this.checkBox6);
            this.panel1.Controls.Add(this.checkBox5);
            this.panel1.Controls.Add(this.checkBox4);
            this.panel1.Controls.Add(this.checkBox3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.checkBox2);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.chkCensus_2000_Tracts);
            this.panel1.Controls.Add(this.chkCensus_2000_Blocks);
            this.panel1.Controls.Add(this.lblCensus_2000);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(547, 547);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // chkCensus_2001_Tracts
            // 
            this.chkCensus_2001_Tracts.AutoSize = true;
            this.chkCensus_2001_Tracts.Location = new System.Drawing.Point(45, 82);
            this.chkCensus_2001_Tracts.Name = "chkCensus_2001_Tracts";
            this.chkCensus_2001_Tracts.Size = new System.Drawing.Size(83, 17);
            this.chkCensus_2001_Tracts.TabIndex = 16;
            this.chkCensus_2001_Tracts.Tag = "Census_Tracts";
            this.chkCensus_2001_Tracts.Text = "2000 Tracts";
            this.chkCensus_2001_Tracts.UseMnemonic = false;
            this.chkCensus_2001_Tracts.UseVisualStyleBackColor = true;
            this.chkCensus_2001_Tracts.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(316, 83);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(86, 17);
            this.checkBox9.TabIndex = 15;
            this.checkBox9.Tag = "Gas_Stations";
            this.checkBox9.Text = "Gas Stations";
            this.checkBox9.UseVisualStyleBackColor = true;
            this.checkBox9.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(316, 107);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(57, 17);
            this.checkBox8.TabIndex = 14;
            this.checkBox8.Tag = "Motels";
            this.checkBox8.Text = "Motels";
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(316, 36);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(122, 17);
            this.checkBox7.TabIndex = 13;
            this.checkBox7.Tag = "Convenience_Stores";
            this.checkBox7.Text = "Convenience Stores";
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(45, 170);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(78, 17);
            this.checkBox6.TabIndex = 12;
            this.checkBox6.Tag = "Cemeteries";
            this.checkBox6.Text = "Cemeteries";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(46, 147);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(76, 17);
            this.checkBox5.TabIndex = 11;
            this.checkBox5.Tag = "Attractions";
            this.checkBox5.Text = "Attractions";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(45, 193);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(105, 17);
            this.checkBox4.TabIndex = 10;
            this.checkBox4.Tag = "Points_of_Interest";
            this.checkBox4.Text = "Points of Interest";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(45, 216);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(115, 17);
            this.checkBox3.TabIndex = 9;
            this.checkBox3.Tag = "Population_Centers";
            this.checkBox3.Text = "Population Centers";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 16);
            this.label2.TabIndex = 8;
            this.label2.Text = "Other";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(316, 130);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(92, 17);
            this.checkBox2.TabIndex = 7;
            this.checkBox2.Tag = "Purple_Parrots";
            this.checkBox2.Text = "Purple Parrots";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(316, 59);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(121, 17);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Tag = "Financial_Institutions";
            this.checkBox1.Text = "Financial Institutions";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(284, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Businesses   ";
            // 
            // chkCensus_2000_Tracts
            // 
            this.chkCensus_2000_Tracts.AutoSize = true;
            this.chkCensus_2000_Tracts.Location = new System.Drawing.Point(46, 59);
            this.chkCensus_2000_Tracts.Name = "chkCensus_2000_Tracts";
            this.chkCensus_2000_Tracts.Size = new System.Drawing.Size(117, 17);
            this.chkCensus_2000_Tracts.TabIndex = 4;
            this.chkCensus_2000_Tracts.Tag = "Census_Block_Groups";
            this.chkCensus_2000_Tracts.Text = "2000 Block Groups";
            this.chkCensus_2000_Tracts.UseVisualStyleBackColor = true;
            this.chkCensus_2000_Tracts.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // chkCensus_2000_Blocks
            // 
            this.chkCensus_2000_Blocks.AutoSize = true;
            this.chkCensus_2000_Blocks.Location = new System.Drawing.Point(46, 36);
            this.chkCensus_2000_Blocks.Name = "chkCensus_2000_Blocks";
            this.chkCensus_2000_Blocks.Size = new System.Drawing.Size(85, 17);
            this.chkCensus_2000_Blocks.TabIndex = 3;
            this.chkCensus_2000_Blocks.Tag = "Census_Blocks";
            this.chkCensus_2000_Blocks.Text = "2000 Blocks";
            this.chkCensus_2000_Blocks.UseVisualStyleBackColor = true;
            this.chkCensus_2000_Blocks.CheckedChanged += new System.EventHandler(this.CheckedChanged);
            // 
            // lblCensus_2000
            // 
            this.lblCensus_2000.AutoSize = true;
            this.lblCensus_2000.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCensus_2000.Location = new System.Drawing.Point(14, 17);
            this.lblCensus_2000.Name = "lblCensus_2000";
            this.lblCensus_2000.Size = new System.Drawing.Size(107, 16);
            this.lblCensus_2000.TabIndex = 2;
            this.lblCensus_2000.Text = "2000 Census   ";
            // 
            // ucCensus
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "ucCensus";
            this.Size = new System.Drawing.Size(573, 563);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox chkCensus_2000_Blocks;
        private System.Windows.Forms.Label lblCensus_2000;
        private System.Windows.Forms.CheckBox chkCensus_2000_Tracts;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox chkCensus_2001_Tracts;

    }
}
